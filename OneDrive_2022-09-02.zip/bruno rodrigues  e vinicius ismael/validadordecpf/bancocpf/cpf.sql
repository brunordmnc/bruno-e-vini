create database bdcpf;
use bdcpf;

create table cpf
(
id int unsigned not null auto_increment,
cpf varchar(12)not null,
cnpj varchar(11)not null,
PRIMARY KEY (id)

);






